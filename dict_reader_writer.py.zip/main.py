import csv 
import os 
def writefun(x,y,z):
 file_ecxist=os.path.isfile("file.csv")
 try:
    with open("file.csv",'a') as f:
        fnames=['name','lastname','age']
        writer=csv.DictWriter(f,fieldnames=fnames,dialect='excel-tab')
        if not file_ecxist or(file_ecxist and f.tell()==0):    
            writer.writeheader()
        try:   
            writer.writerow({'name':x,'lastname':y,"age":n})
        except OSError as error:
            print('the problem is',error)
        finally:
            f.close()
 except FileNotFoundError as notfound:
        print("the problem is the:",notfound)
def readfun():
    with open("file.csv", "r") as file:
        try:
            reader=csv.DictReader(file)
            for row in reader:
                if reader.line_num==1:
                    continue
                print(row.get('name', 'N/A'), row.get('lastname', 'N/A'), row.get('age', 'N/A'))
        except OSError as x:
            print("the problem is",x)
        finally:
            file.close()

if __name__=="__main__":
    print("Please enter name last name and age\n")
    while True:
      x=input("name:")
      y=input("lastname:")
      n=input("age:")
      if x=="0" or y=="0" or n=="0":
          break
      writefun(x,y,n)
    print("the programm is finished if you want to see the data the have entered in csv file please pres 1")
    print("if you want to finish the programm please enter 2")
    z=input("enter the value:")
    if z=='1':
      readfun()
    elif z=='2':
        print("the programm is finished")
    else:
        print("the programm is finished!")